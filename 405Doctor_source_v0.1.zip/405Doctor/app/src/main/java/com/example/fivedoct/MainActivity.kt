package com.example.fivedoct

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val executor = Executors.newSingleThreadExecutor()
    private var socket: BluetoothSocket? = null
    private var connected = false
    private var running = false

    private lateinit var status: TextView
    private lateinit var values: TextView
    private lateinit var log: TextView
    private lateinit var chart: MiniChart
    private lateinit var connectButton: Button
    private lateinit var liveButton: Button
    private lateinit var errorsButton: Button
    private val tempHistory = mutableListOf<Float>()
    private val rpmHistory = mutableListOf<Float>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        status.text = "آماده اتصال؛ دانگل OBDII را روشن و جفت‌سازی کنید."
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
            setBackgroundColor(0xFF101820.toInt())
        }
        scroll.addView(layout)
        setContentView(scroll)

        fun label(text: String, size: Float = 16f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFFF2F5F7.toInt())
                setPadding(0, 10, 0, 10)
            }

        layout.addView(label("405 DOCTOR", 26f))
        layout.addView(label("عیب‌یاب پایه OBD2 پژو ۴۰۵", 17f))
        status = label("وضعیت: قطع", 15f)
        layout.addView(status)

        connectButton = Button(this).apply {
            text = "اتصال به دانگل OBDII"
            setOnClickListener { connectToPairedDevice() }
        }
        layout.addView(connectButton)

        liveButton = Button(this).apply {
            text = "شروع / توقف اطلاعات زنده"
            isEnabled = false
            setOnClickListener { toggleLive() }
        }
        layout.addView(liveButton)

        errorsButton = Button(this).apply {
            text = "خواندن خطاهای ذخیره‌شده (Mode 03)"
            isEnabled = false
            setOnClickListener { readErrors() }
        }
        layout.addView(errorsButton)

        layout.addView(label("اطلاعات لحظه‌ای", 20f))
        values = label("دمای آب: -- °C\nدور موتور: -- rpm\nسرعت: -- km/h\nولتاژ ECU: -- V", 18f)
        layout.addView(values)

        layout.addView(label("نمودار دما و دور موتور", 18f))
        chart = MiniChart(this)
        chart.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 280
        )
        layout.addView(chart)

        layout.addView(label("فن و سیستم CNG", 20f))
        layout.addView(label(
            "فن: لا يوجد PID قياسي موثوق لحالة أمر تشغيل المروحة. سنعرضها كـ«غير متاح» حتى نثبت PID الخاص بوحدة التحكم.\n" +
            "CNG: بيانات ضغط/حرارة الغاز وحالة التحويل تعتمد على وحدة الغاز وبروتوكولها؛ لا تُرسل أوامر تخمينية.",
            14f
        ))
        layout.addView(label("سجل الاتصال", 18f))
        log = label("لا توجد بيانات بعد.", 13f)
        layout.addView(log)
    }

    private fun appendLog(line: String) {
        runOnUiThread {
            log.text = (log.text.toString() + "\n" + line).takeLast(5000)
        }
    }

    private fun connectToPairedDevice() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            status.text = "این گوشی بلوتوث ندارد."
            return
        }
        if (!adapter.isEnabled) {
            status.text = "ابتدا بلوتوث گوشی را روشن کنید."
            return
        }
        executor.execute {
            try {
                val device = adapter.bondedDevices.firstOrNull {
                    it.name?.contains("OBDII", ignoreCase = true) == true
                } ?: adapter.bondedDevices.firstOrNull {
                    it.name?.contains("OBD", ignoreCase = true) == true
                }
                if (device == null) {
                    runOnUiThread { status.text = "دانگل جفت‌شده با نام OBDII پیدا نشد." }
                    return@execute
                }
                appendLog("دانگل پیدا شد: ${device.name} / ${device.address}")
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                connected = true
                val init = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")
                init.forEach { cmd ->
                    val response = sendCommand(cmd)
                    appendLog("$cmd  ->  ${response.trim()}")
                }
                runOnUiThread {
                    status.text = "متصل به ${device.name}"
                    liveButton.isEnabled = true
                    errorsButton.isEnabled = true
                    connectButton.text = "اتصال برقرار است"
                }
            } catch (e: Exception) {
                connected = false
                closeSocket()
                appendLog("خطای اتصال: ${e.message}")
                runOnUiThread { status.text = "اتصال ناموفق؛ دانگل و جفت‌سازی را بررسی کنید." }
            }
        }
    }

    @Synchronized
    @Throws(IOException::class)
    private fun sendCommand(command: String): String {
        val s = socket ?: throw IOException("Socket is closed")
        s.outputStream.write((command + "\r").toByteArray(Charsets.US_ASCII))
        s.outputStream.flush()
        val out = StringBuilder()
        val deadline = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < deadline) {
            if (s.inputStream.available() > 0) {
                val b = s.inputStream.read()
                if (b < 0) break
                val c = b.toChar()
                if (c == '>') break
                out.append(c)
            } else {
                Thread.sleep(20)
            }
        }
        return out.toString().replace("\r", " ").replace("\n", " ").trim()
    }

    private fun toggleLive() {
        if (running) {
            running = false
            liveButton.text = "ادامه اطلاعات زنده"
        } else {
            running = true
            liveButton.text = "توقف اطلاعات زنده"
            executor.execute { liveLoop() }
        }
    }

    private fun liveLoop() {
        while (running && connected) {
            try {
                val tempRaw = sendCommand("0105")
                val rpmRaw = sendCommand("010C")
                val speedRaw = sendCommand("010D")
                val voltRaw = sendCommand("ATRV")

                val temp = parsePid(tempRaw, "4105")?.let { it - 40 }
                val rpm = parsePid16(rpmRaw, "410C")?.let { it / 4 }
                val speed = parsePid(speedRaw, "410D")
                val volt = Regex("""(\d+(?:\.\d+)?)""").find(voltRaw)?.value

                if (temp != null) synchronized(tempHistory) {
                    tempHistory.add(temp.toFloat()); if (tempHistory.size > 60) tempHistory.removeAt(0)
                }
                if (rpm != null) synchronized(rpmHistory) {
                    rpmHistory.add(rpm.toFloat()); if (rpmHistory.size > 60) rpmHistory.removeAt(0)
                }
                runOnUiThread {
                    values.text = "دمای آب: ${temp?.let { "$it °C" } ?: "--"}\n" +
                        "دور موتور: ${rpm?.let { "$it rpm" } ?: "--"}\n" +
                        "سرعت: ${speed?.let { "$it km/h" } ?: "--"}\n" +
                        "ولتاژ دانگل: ${volt?.let { "$it V" } ?: "--"}"
                    chart.setData(tempHistory.toList(), rpmHistory.toList())
                }
            } catch (e: Exception) {
                appendLog("خطای خواندن اطلاعات: ${e.message}")
                running = false
                break
            }
            Thread.sleep(500)
        }
        runOnUiThread { liveButton.text = "شروع اطلاعات زنده" }
    }

    private fun parsePid(response: String, header: String): Int? {
        val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
        val index = hex.indexOf(header)
        if (index < 0 || hex.length < index + header.length + 2) return null
        return hex.substring(index + header.length, index + header.length + 2).toIntOrNull(16)
    }

    private fun parsePid16(response: String, header: String): Int? {
        val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
        val index = hex.indexOf(header)
        if (index < 0 || hex.length < index + header.length + 4) return null
        return hex.substring(index + header.length, index + header.length + 4).toIntOrNull(16)
    }

    private fun readErrors() {
        executor.execute {
            try {
                val response = sendCommand("03")
                val codes = decodeDtc(response)
                val message = if (codes.isEmpty()) "کد خطای قابل‌خواندن دریافت نشد؛ پاسخ خام: $response"
                    else "کدهای خطا:\n" + codes.joinToString("\n")
                runOnUiThread { AlertDialog.Builder(this).setTitle("خطاهای ECU").setMessage(message).setPositiveButton("باشه", null).show() }
                appendLog("Mode 03: $response")
            } catch (e: Exception) {
                appendLog("خطا در خواندن کدها: ${e.message}")
            }
        }
    }

    private fun decodeDtc(response: String): List<String> {
        val hex = response.uppercase().replace(Regex("[^0-9A-F]"), "")
        val marker = hex.indexOf("43")
        if (marker < 0) return emptyList()
        val payload = hex.substring(marker + 2)
        val result = mutableListOf<String>()
        var i = 0
        while (i + 4 <= payload.length) {
            val a = payload.substring(i, i + 2).toIntOrNull(16) ?: break
            val b = payload.substring(i + 2, i + 4).toIntOrNull(16) ?: break
            i += 4
            if (a == 0 && b == 0) continue
            val prefix = when ((a and 0xC0) shr 6) {
                0 -> "P"; 1 -> "C"; 2 -> "B"; else -> "U"
            }
            val digit = (a and 0x30) shr 4
            result.add(prefix + digit + "%02X".format(a and 0x0F) + "%02X".format(b))
        }
        return result
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        connected = false
    }

    override fun onDestroy() {
        running = false
        closeSocket()
        executor.shutdownNow()
        super.onDestroy()
    }
}

class MiniChart(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var temps: List<Float> = emptyList()
    private var rpms: List<Float> = emptyList()

    fun setData(t: List<Float>, r: List<Float>) {
        temps = t; rpms = r; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        paint.color = 0xFF263746.toInt()
        paint.strokeWidth = 2f
        for (i in 1..3) canvas.drawLine(20f, h * i / 4f, w - 20f, h * i / 4f, paint)
        drawSeries(canvas, temps, h, 0xFFFFB74D.toInt(), 0f, 120f)
        drawSeries(canvas, rpms, h, 0xFF4FC3F7.toInt(), 0f, 6000f)
        paint.color = 0xFFF2F5F7.toInt()
        paint.textSize = 28f
        canvas.drawText("دما (نارنجی)  |  RPM (آبی)", 24f, 34f, paint)
    }

    private fun drawSeries(canvas: Canvas, data: List<Float>, h: Float, color: Int, minV: Float, maxV: Float) {
        if (data.size < 2) return
        val path = Path()
        val usableW = width - 48f
        val usableH = h - 70f
        data.forEachIndexed { i, v ->
            val x = 24f + usableW * i / max(1, data.size - 1)
            val normalized = ((v - minV) / (maxV - minV)).coerceIn(0f, 1f)
            val y = h - 20f - normalized * usableH
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        paint.color = color
        paint.strokeWidth = 4f
        paint.style = Paint.Style.STROKE
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.FILL
    }
}
